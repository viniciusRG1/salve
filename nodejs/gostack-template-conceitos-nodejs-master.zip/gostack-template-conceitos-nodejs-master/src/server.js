const app = require("./app");

app.listen(3333);
