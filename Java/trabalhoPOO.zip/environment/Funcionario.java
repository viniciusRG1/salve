public class Funcionario{
    private String CPF;
    private String nomeCompleto;
    private String nroCarteiraDeTrabalho;
    private String rg;
    private String dataDeNascimento;
    private String endereco;
    private String sexo;
    private String estadoCivil;
    private String cargo;
    private float salario;
    private String dataIngresso;
    
    public Funcionario(String CPF, String nomeCompleto, String nroCarteiraDeTrabalho, String rg, String dataDeNascimento, String endereco, String sexo, String estadoCivil, String cargo, float salario, String dataIngresso){
        this.setCPF(CPF);
        this.setNomeCompleto(nomeCompleto);
        this.setNroCarteiraDeTrabalho(nroCarteiraDeTrabalho);
        this.setRg(rg);
        this.setDataDeNascimento(dataNascimento);
        this.setEndereco(endereco);
        this.setSexo(sexo);
        this.setEstadoCivil(estadoCivil);
        this.setCargo(cargo);
        this.setSalario(salario);
        this.setDataIngresso(dataIngresso);
    }
    
    private void setCPF(String CPF){
        this.CPF = CPF;
    }
    
    private void setNomeCompleto(String nomeCompleto){
        this.nomeCompleto = nomeCompleto;
    }
    
    private void setNroCarteiraDeTrabalho(String nroCarteiraDeTrabalho){
        this.nroCarteiraDeTrabalho = nroCarteiraDeTrabalho;
    }
    
    private void setRg(String rg){
        this.rg = rg;
    }
    
    private void setDataDeNascimento(String dataDeNascimento){
        this.dataDeNascimento = dataDeNascimento;
    }
    
    public void setEndereco(String endereco){
        this.endereco = endereco;
    }
    
    private void setSexo(String sexo){
        this.sexo = sexo;
    }
    
    public void setEstadoCivil(String estadoCivil){
        this.estadoCivil = estadoCivil;
    }
    
    private void setCargo(String cargo){
        this.cargo = cargo;
    }
    
    public void setSalario(float salario){
        this.salario = salario;
    }
    
    private void dataIngresso(String dataIngresso){
        this.dataIngresso = dataIngresso;
    }
    
    public String mostrarCPF(){
        return this.CPF;
    }
    
    public String mostrarNomeCompleto(){
        return this.nomeCompleto;
    }
    
    public String mostrarNroCarteiraDeTrabalho(){
        return this.nroCarteiraDeTrabalho;
    }
    
    public String mostrarRg(){
        return this.rg;
    }
    
    public String mostrarDataDeNascimento(){
        return this.dataDeNascimento;
    }
    
    public String mostrarEndereco(){
        return this.endereco;
    }
    
    public String mostrarSexo(){
        return this.Sexo;
    }
    
    public String mostrarEstadoCivil(){
        return this.estadoCivil;
    }
    
    public String mostrarCargo(){
        return this.cargo;
    }
    
    public float mostrarSalario(){
        return this.salario;
    }
    
    public String mostrarDataIngresso(){
        return this.dataIngresso;
    }

    
}


