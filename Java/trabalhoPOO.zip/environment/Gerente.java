public class Gerente extends Funcionario{
    private boolean empregado;
    private Agencia agenciaDoGerente;
    private String ingressoParaGerente;
    private boolean cursoCompleto;
    
    public boolean mostrarSeTemEmprego(){
        return this.empregado;
    }
    
    public void empregarOuDesempregar(){
        if(this.mostrarSeTemEmprego() == true){
            this.empregado = false;
        }else{
            this.empregado = true;
        }
    }
    
    public void setAgencia(Agencia agenciaDoGerente){
        this.agenciaDoGerente(agenciaDoGernete);
    }
    
    public String verAgencia(){
       return this.agenciaDoGerente.mostrarNome+"\n"this.agenciaDoGerente.mostrarNumero;
    }
    
    public boolean fezCurso(){
        return this.cursoCompleto;
    }
    
    public void cursoConcluido(){
        if(this.fezCurso() == false){
            this.cursoCompleto = true;
        }else{
            this.cursoCompleto = true;
        }
    }
}