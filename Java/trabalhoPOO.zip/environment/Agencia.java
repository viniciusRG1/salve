public class Agencia{
    private int numero;
    private String nome;
    private String endereco;
    private String cidade;
    private String estado;
    private String bairro;
    private Funcionario gerente;
    
    public Agencia(int numero, String nome, String endereco, String cidade, String estado, String bairro){
        this.setNumero(numero);
        this.setNome(nome);
        this.setEndereco(endereco);
        this.setCidade(cidade);
        this.setEstado(estado);
        this.setBairro(bairro);
    }
    
    public int numeroDaAgencia (){
        return this.numero;
    }
    
    private void setNumero(int numero){
        this.numero = numero;
    }
    
    public String nomeDaAgencia(){
        return this.endereco;
    }
    
    private void setAgencia(String agencia){
        return this.agencia;
    } 
    
    public String enderecoDaAgencia(){
        return this.endereco;
    }
    
    private void setEndereco(String endereco){
        this.endereco = endereco;
    }
    
    public String cidadeDaAgencia(){
        return this.cidade;
    }
    
    private void setCidade(String cidade){
        this.cidade = cidade;
    }
    
    public String EstadoDaAgencia(){
        return this.estado;
    }
    
    private void setEstado(String estado){
        this.estado = estado;
    }
    
    public String bairroDaAgencia(){
        return this.bairro;
    }
    
    private void setBairro(String bairro){
        this.bairro = bairro;
    }
    
    public String mostrarInfo(){
        return "as informações da agencia são: \n numero da agência:"+ this.numeroDaAgencia +"\n nome da agência:"+this.nomeDaAgencia+"\n endereço da agência:"+this.enderecoDaAgencia+"\n cidade da agência:"+this.cidadeDaAgencia+"\n estado da agência:"+this.estadoDaAgencia+"\n bairro da agência:"+this.bairroDaAgencia;
    }
}