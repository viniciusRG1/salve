const timeOut = 3000
const finished = () => console.log('done!')

let timer = setTimeout(finished, timeOut) // será executada depois da função abaixo
clearTimeout(timer) // serve para poder cancelar um setTimeout em execução

