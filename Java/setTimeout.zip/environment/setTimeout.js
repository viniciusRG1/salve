const timeOut = 3000
const finished = () => console.log('done!')

setTimeout(finished, timeOut) // será executada depois da função abaixo
console.log('mostrar') // isso será mostrado antes da função finished ser chamada novamente
