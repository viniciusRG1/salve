const timeOut = 1000
const checking = () => console.log('checking')

let interval = setInterval(checking, timeOut) // a cada X milissegundos terá a função executada

setTimeout(() => clearInterval(interval), 6000)