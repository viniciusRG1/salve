
function getFlags(flag){
    const index = process.argv.indexOf(flag)
    return process.argv[index]
}
module.exports = getFlags;