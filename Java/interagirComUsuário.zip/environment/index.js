const question = [
    "oi quem é vc ?",
    "esta bem ?"
    ]
    
const ask = (index = 0) => {
    process.stdout.write(question[index] + " > ")
}

ask()

const answers = []
process.stdin.on("data", data => {
    //process.stdout.write(data.toString().trim() + '\n')// aqui não finalizara o processo e ele fcará executando eternamente
    answers.push(data.toString().trim())
    if(answers.length < question.length){
        ask(answers.length)
    }else{
        console.log(answers)
        process.exit()
    }
})

process.on('exit', () => {
    console.log(`
        fico feliz que vc esteja feliz ${answers[0]}
    `)
})