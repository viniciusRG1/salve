const getFlagValue = require('./exports')

console.log(`oi ${getFlagValue--name')}. ${getFlagValue('--greeting')}`)