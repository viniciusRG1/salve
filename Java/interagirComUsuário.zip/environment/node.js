//global.console.log('teste 123')
//console.log(global)
// require
//console.log(require()) // assim é incorreto, pois não está mandando nada.
//console.log(require('path'))
//salva em uma constante
//const path = require('path')
//mostra o nome do arquivo
//console.log(path.basename(__filename))
//export
//é oque está escrito no arquivo exports.js
//module.exports = "enviando dados"
//fim
//const myModule = require('./exports')
//console.log(myModule)
//process
//aqui utilizamos os argumentos que foram dados no inicío para usar dentro do programa
//console.log(process.argv)
//console.log('seu nome é ', process.argv[2]+ ' ' +process.argv[3])
//const firstName = process.argv[2]
//const lastName = process.argv[3]
//console.log(`seu nome é ${firstName} ${lastName}`)
//flags
//modo de mandar argv ==name"vinicius" <-- isso é uma flag
